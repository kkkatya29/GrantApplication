﻿using GrantApplication.Model;
using GrantApplication.Repository;

namespace GrantApplication;

public partial class FormLogin : Form
{
    private UserRepository UserRepository = new();
    public FormLogin()
    {
        InitializeComponent();
    }

    private void label2_Click(object sender, EventArgs e)
    {
        FormRegistration form = new();
        form.Show();
        this.Hide();
    }

    private void guna2Button4_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(guna2TextBox1.Text) || string.IsNullOrEmpty(guna2TextBox2.Text))
        {
            MessageBox.Show("Заполните логин и пароль.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        UserModel user = new()
        {
            Login = guna2TextBox1.Text,
            Password = guna2TextBox2.Text
        };

        if (UserRepository.LoginUser(user))
        {
            MessageBox.Show("Вход успешно выполнен!", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            FormMain formMain = new();
            formMain.Show();
            this.Hide();
        }
        else
        {
            MessageBox.Show("Логин и/или пароль введены не верно.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void guna2CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        guna2TextBox2.UseSystemPasswordChar = guna2CheckBox1.Checked;
    }

    private void FormLogin_Load(object sender, EventArgs e)
    {
        guna2CheckBox1.Checked = true;
    }
}
