using GrantApplication.StaticModel;

namespace GrantApplication;

public partial class FormMain : Form
{
    private Form AcriveForm { get; set; } = null;

    public FormMain()
    {
        InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
        SetAccess(CurrentUser.Role);
    }

    private void guna2Button1_Click(object sender, EventArgs e)
    {
        OpenForm(new FormCreateRequest());
    }


    private void OpenForm(Form childForm)
    {
        AcriveForm?.Close();
        AcriveForm = childForm;
        childForm.TopLevel = false;
        childForm.FormBorderStyle = FormBorderStyle.None;
        childForm.Dock = DockStyle.Fill;
        panel3.Controls.Add(childForm);
        panel3.Tag = childForm;
        childForm.BringToFront();
        childForm.Show();
    }

    private void guna2Button2_Click(object sender, EventArgs e)
    {
        OpenForm(new FormManipulationRequest());
    }

    private void guna2Button4_Click(object sender, EventArgs e)
    {
        OpenForm(new FormAdmin());
    }

    private void guna2Button5_Click(object sender, EventArgs e)
    {
        FormLogin form = new();
        form.Show();
        this.Hide();
    }

    private void guna2Button3_Click(object sender, EventArgs e)
    {
        OpenForm(new FormEmployee());
    }

    private void SetAccess(string role)
    {
        switch (role.ToLower())
        {
            case "������":
                guna2Button3.Dispose();
                guna2Button4.Dispose();
                break;
            case "��������":
                guna2Button1.Dispose();
                guna2Button4.Dispose();
                break;
            case "�����":
                guna2Button1.Dispose();
                break;
            default:
                panel2.Dispose();
                MessageBox.Show("���� ������������.", "�����������", MessageBoxButtons.OK, MessageBoxIcon.Information);
                break;
        }
    }
}
