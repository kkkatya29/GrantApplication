﻿using GrantApplication.Model;
using GrantApplication.Repository;
using GrantApplication.Validator;

namespace GrantApplication;

public partial class FormFillPersonalData : Form
{
    private UserModel UserModel = new();
    private StudentValidator StudentValidator = new();
    private UserRepository UserRepository = new();
    private StudentRepository StudentRepository = new();
    private EducationRepository EducationRepository = new();

    public FormFillPersonalData(UserModel user)
    {
        InitializeComponent();
        UserModel = user;
    }

    private void label2_Click(object sender, EventArgs e)
    {
        FormLogin form = new();
        form.Show();
        this.Hide();
    }

    private void guna2Button4_Click(object sender, EventArgs e)
    {
        StudentModel student = new()
        {
            LastName = guna2TextBox1.Text,
            FirstName = guna2TextBox2.Text,
            MiddleName = guna2TextBox3.Text,
            EducationId = (int)guna2ComboBox3.SelectedValue
        };

        if (!StudentValidator.Validate(student))
        {
            return;
        }

        if (!StudentRepository.CreateStudent(student))
        {
            return;
        }

        if (!UserRepository.CreateUser(UserModel))
        {
            return;
        }

        if (UserRepository.OwnerAccountSet(UserRepository.GetLastUserId(), StudentRepository.GetLastStudentId(), 1))
        {
            MessageBox.Show("Аккаунт успешно создан!", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            FormLogin form = new();
            form.Show();
            this.Hide();
        }
    }

    private void FormFillPersonalData_Load(object sender, EventArgs e)
    {
        FillCombobox();
    }

    private void FillCombobox()
    {
        guna2ComboBox3.DataSource = EducationRepository.GetEducationAll();
        guna2ComboBox3.DisplayMember = "Наименование";
        guna2ComboBox3.ValueMember = "ID учебного завендения";
        guna2ComboBox3.SelectedIndex = 0;
    }
}
