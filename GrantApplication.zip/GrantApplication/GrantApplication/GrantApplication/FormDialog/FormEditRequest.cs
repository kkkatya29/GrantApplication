﻿using GrantApplication.Model;
using GrantApplication.Repository;

namespace GrantApplication.FormDialog;

public partial class FormEditRequest : Form
{
    private FormManipulationRequest FormManipulationRequest;
    private RequestRepository RequestRepository { get; set; } = new();
    private RequestModel RequestInput { get; set; } = new();
    private CountryRepository CountryRepository { get; set; } = new();
    private GrantRepository GrantRepository { get; set; } = new();

    public FormEditRequest(FormManipulationRequest formManipulation, RequestModel request)
    {
        InitializeComponent();
        FormManipulationRequest = formManipulation;
        RequestInput = request;
    }

    private void guna2Button4_Click(object sender, EventArgs e)
    {
        RequestModel request = new()
        {
            RequestId = RequestInput.RequestId,
            RequestName = guna2TextBox1.Text,
            Description = guna2TextBox2.Text,
            Cost = guna2TextBox3.Text,
            CountryId = (int)guna2ComboBox3.SelectedValue,
            GrantTypeId = (int)guna2ComboBox1.SelectedValue,
            ApplicationDeadline = guna2DateTimePicker1.Value
        };

        if (RequestRepository.UpdateRequest(request))
        {
            FormManipulationRequest.LoadDataGrid();
            MessageBox.Show("Данные заявки успешно обновлены!", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
    }

    private void FormEditRequest_Load(object sender, EventArgs e)
    {
        FillCombobox();
        SetDataControl();
    }

    private void SetDataControl()
    {
        guna2TextBox1.Text = RequestInput.RequestName;
        guna2TextBox2.Text = RequestInput.Description;
        guna2TextBox3.Text = RequestInput.Cost;
        guna2ComboBox1.SelectedValue = RequestInput.GrantTypeId;
        guna2ComboBox3.SelectedValue = RequestInput.CountryId;
        guna2DateTimePicker1.Value = (DateTime)RequestInput.ApplicationDeadline;
    }

    private void FillCombobox()
    {
        guna2ComboBox1.DataSource = CountryRepository.GetCountryAll();
        guna2ComboBox1.DisplayMember = "Наименование";
        guna2ComboBox1.ValueMember = "ID Страны";
        guna2ComboBox1.SelectedIndex = 0;

        guna2ComboBox3.DataSource = GrantRepository.GetGrantAll();
        guna2ComboBox3.DisplayMember = "Наименование";
        guna2ComboBox3.ValueMember = "ID Вида гранта";
        guna2ComboBox3.SelectedIndex = 0;
    }
}
