﻿using GrantApplication.Model;
using GrantApplication.Repository;

namespace GrantApplication.FormDialog;

public partial class FormEditRequestStatus : Form
{
    private FormManipulationRequest FormManipulationRequest;
    private RequestRepository RequestRepository { get; set; } = new();
    private StatusRepository StatusRepository { get; set; } = new();
    private RequestModel RequestModel { get; set; }

    public FormEditRequestStatus(FormManipulationRequest formManipulationRequest, RequestModel requestModel)
    {
        InitializeComponent();
        FormManipulationRequest = formManipulationRequest;
        RequestModel = requestModel;
    }

    private void guna2Button4_Click(object sender, EventArgs e)
    {
        RequestModel request = new()
        {
            RequestId = RequestModel.RequestId,
            StatusId = (int)guna2ComboBox3.SelectedValue
        };

        if (RequestRepository.UpdateRequestStatus(request))
        {
            FormManipulationRequest.LoadDataGrid();
            MessageBox.Show("Статус успешно обновлен!", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
    }

    private void FormEditRequestStatus_Load(object sender, EventArgs e)
    {
        FillCombobox();
        guna2ComboBox3.SelectedValue = RequestModel.StatusId;
    }

    private void FillCombobox()
    {
        guna2ComboBox3.DataSource = StatusRepository.GetStatusAll();
        guna2ComboBox3.DisplayMember = "Наименование";
        guna2ComboBox3.SelectedIndex = 0;
        guna2ComboBox3.ValueMember = "ID Статуса";
    }
}
