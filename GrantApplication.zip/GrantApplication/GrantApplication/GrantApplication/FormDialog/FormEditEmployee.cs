﻿using GrantApplication.Model;
using GrantApplication.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GrantApplication.FormDialog;

public partial class FormEditEmployee : Form
{
    private FormEmployee FormEmployee;
    private EmployeeModel EmployeeInput { get; set; } = new();
    private EmployeeRepository EmployeeRepository { get; set; } = new();
    private int Option { get; set; }//1-add, 2-edit.

    public FormEditEmployee(FormEmployee formEmployee, EmployeeModel employee, int option)
    {
        InitializeComponent();
        EmployeeInput = employee;
        FormEmployee = formEmployee;
        Option = option;
    }

    private void FormEditEmployee_Load(object sender, EventArgs e)
    {
        if (Option == 2)
        {
            guna2TextBox1.Text = EmployeeInput.LastName;
            guna2TextBox2.Text = EmployeeInput.FirstName;
            guna2TextBox3.Text = EmployeeInput.MiddleName;
            label2.Text = "Изменение сотрудника";
            guna2Button4.Text = "Сохранить";
        }
        else
        {
            label2.Text = "Добавление сотрудника";
            guna2Button4.Text = "Добавить";
        }
    }

    private void guna2Button4_Click(object sender, EventArgs e)
    {
        EmployeeModel employee = new()
        {
            EmployeeId = EmployeeInput.EmployeeId,
            FirstName = guna2TextBox2.Text,
            LastName = guna2TextBox1.Text,
            MiddleName = guna2TextBox3.Text
        };

        if (Option == 1) //add
        {
            if (EmployeeRepository.CreateEmployee(employee))
            {
                FormEmployee.LoadDataGrid();
                MessageBox.Show("Сотрудник успешно добавлен!", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
                return;
            }
        }
        else //edit
        {
            if (EmployeeRepository.UpdateEmployee(employee))
            {
                FormEmployee.LoadDataGrid();
                MessageBox.Show("Сотрудник успешно обновлен!", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
                return;
            }
        }
    }
}
