﻿namespace GrantApplication.FormDialog
{
    partial class FormEditRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label10 = new Label();
            label9 = new Label();
            guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label4 = new Label();
            guna2DateTimePicker1 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            guna2TextBox3 = new Guna.UI2.WinForms.Guna2TextBox();
            label3 = new Label();
            guna2ComboBox3 = new Guna.UI2.WinForms.Guna2ComboBox();
            label1 = new Label();
            guna2ComboBox1 = new Guna.UI2.WinForms.Guna2ComboBox();
            guna2TextBox2 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(components);
            panel1 = new Panel();
            label2 = new Label();
            guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.None;
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 10F);
            label10.ForeColor = Color.FromArgb(64, 64, 64);
            label10.Location = new Point(345, 305);
            label10.Name = "label10";
            label10.Size = new Size(95, 19);
            label10.TabIndex = 39;
            label10.Text = "Срок подачи:";
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.None;
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10F);
            label9.ForeColor = Color.FromArgb(64, 64, 64);
            label9.Location = new Point(44, 307);
            label9.Name = "label9";
            label9.Size = new Size(55, 19);
            label9.TabIndex = 38;
            label9.Text = "Сумма:";
            // 
            // guna2Button4
            // 
            guna2Button4.Anchor = AnchorStyles.None;
            guna2Button4.Animated = true;
            guna2Button4.BackColor = Color.Transparent;
            guna2Button4.BorderColor = Color.FromArgb(43, 43, 43);
            guna2Button4.BorderRadius = 12;
            guna2Button4.CheckedState.FillColor = Color.FromArgb(40, 40, 40);
            guna2Button4.Cursor = Cursors.Hand;
            guna2Button4.CustomizableEdges = customizableEdges1;
            guna2Button4.DisabledState.BorderColor = Color.DarkGray;
            guna2Button4.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button4.FillColor = Color.MediumSeaGreen;
            guna2Button4.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            guna2Button4.ForeColor = Color.White;
            guna2Button4.Location = new Point(224, 417);
            guna2Button4.Name = "guna2Button4";
            guna2Button4.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Button4.Size = new Size(202, 47);
            guna2Button4.TabIndex = 37;
            guna2Button4.Text = "Применить";
            guna2Button4.Click += guna2Button4_Click;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.None;
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10F);
            label8.ForeColor = Color.FromArgb(64, 64, 64);
            label8.Location = new Point(44, 166);
            label8.Name = "label8";
            label8.Size = new Size(72, 19);
            label8.TabIndex = 36;
            label8.Text = "Описание";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10F);
            label7.ForeColor = Color.FromArgb(64, 64, 64);
            label7.Location = new Point(44, 99);
            label7.Name = "label7";
            label7.Size = new Size(104, 19);
            label7.TabIndex = 35;
            label7.Text = "Наименование";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label6.ForeColor = Color.FromArgb(64, 64, 64);
            label6.Location = new Point(28, 275);
            label6.Name = "label6";
            label6.Size = new Size(70, 21);
            label6.TabIndex = 34;
            label6.Text = "Прочее";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.ForeColor = Color.FromArgb(64, 64, 64);
            label4.Location = new Point(28, 64);
            label4.Name = "label4";
            label4.Size = new Size(186, 21);
            label4.TabIndex = 32;
            label4.Text = "Информация о гранте";
            // 
            // guna2DateTimePicker1
            // 
            guna2DateTimePicker1.Anchor = AnchorStyles.None;
            guna2DateTimePicker1.BorderRadius = 12;
            guna2DateTimePicker1.Checked = true;
            guna2DateTimePicker1.CustomizableEdges = customizableEdges3;
            guna2DateTimePicker1.FillColor = Color.Silver;
            guna2DateTimePicker1.Font = new Font("Segoe UI", 10F);
            guna2DateTimePicker1.ForeColor = Color.White;
            guna2DateTimePicker1.Format = DateTimePickerFormat.Long;
            guna2DateTimePicker1.Location = new Point(345, 327);
            guna2DateTimePicker1.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            guna2DateTimePicker1.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            guna2DateTimePicker1.Name = "guna2DateTimePicker1";
            guna2DateTimePicker1.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2DateTimePicker1.Size = new Size(266, 41);
            guna2DateTimePicker1.TabIndex = 28;
            guna2DateTimePicker1.Value = new DateTime(2024, 10, 26, 22, 3, 8, 981);
            // 
            // guna2TextBox3
            // 
            guna2TextBox3.Anchor = AnchorStyles.None;
            guna2TextBox3.BorderRadius = 12;
            guna2TextBox3.CustomizableEdges = customizableEdges5;
            guna2TextBox3.DefaultText = "";
            guna2TextBox3.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox3.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox3.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox3.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox3.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox3.Font = new Font("Segoe UI", 10F);
            guna2TextBox3.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox3.Location = new Point(44, 327);
            guna2TextBox3.MaxLength = 14;
            guna2TextBox3.Name = "guna2TextBox3";
            guna2TextBox3.PasswordChar = '\0';
            guna2TextBox3.PlaceholderText = "Введите сумму";
            guna2TextBox3.SelectedText = "";
            guna2TextBox3.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2TextBox3.Size = new Size(266, 41);
            guna2TextBox3.TabIndex = 27;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.ForeColor = Color.FromArgb(64, 64, 64);
            label3.Location = new Point(345, 99);
            label3.Name = "label3";
            label3.Size = new Size(81, 19);
            label3.TabIndex = 26;
            label3.Text = "Вид гранта:";
            // 
            // guna2ComboBox3
            // 
            guna2ComboBox3.Anchor = AnchorStyles.None;
            guna2ComboBox3.BackColor = Color.Transparent;
            guna2ComboBox3.BorderRadius = 12;
            guna2ComboBox3.CustomizableEdges = customizableEdges7;
            guna2ComboBox3.DrawMode = DrawMode.OwnerDrawFixed;
            guna2ComboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
            guna2ComboBox3.FocusedColor = Color.FromArgb(94, 148, 255);
            guna2ComboBox3.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2ComboBox3.Font = new Font("Segoe UI", 10F);
            guna2ComboBox3.ForeColor = Color.FromArgb(68, 88, 112);
            guna2ComboBox3.ItemHeight = 34;
            guna2ComboBox3.Location = new Point(345, 121);
            guna2ComboBox3.Name = "guna2ComboBox3";
            guna2ComboBox3.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2ComboBox3.Size = new Size(266, 40);
            guna2ComboBox3.TabIndex = 25;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(345, 166);
            label1.Name = "label1";
            label1.Size = new Size(57, 19);
            label1.TabIndex = 24;
            label1.Text = "Страна:";
            // 
            // guna2ComboBox1
            // 
            guna2ComboBox1.Anchor = AnchorStyles.None;
            guna2ComboBox1.BackColor = Color.Transparent;
            guna2ComboBox1.BorderRadius = 12;
            guna2ComboBox1.CustomizableEdges = customizableEdges9;
            guna2ComboBox1.DrawMode = DrawMode.OwnerDrawFixed;
            guna2ComboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            guna2ComboBox1.FocusedColor = Color.FromArgb(94, 148, 255);
            guna2ComboBox1.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2ComboBox1.Font = new Font("Segoe UI", 10F);
            guna2ComboBox1.ForeColor = Color.FromArgb(68, 88, 112);
            guna2ComboBox1.ItemHeight = 34;
            guna2ComboBox1.Location = new Point(345, 186);
            guna2ComboBox1.Name = "guna2ComboBox1";
            guna2ComboBox1.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2ComboBox1.Size = new Size(266, 40);
            guna2ComboBox1.TabIndex = 23;
            // 
            // guna2TextBox2
            // 
            guna2TextBox2.Anchor = AnchorStyles.None;
            guna2TextBox2.BorderRadius = 12;
            guna2TextBox2.CustomizableEdges = customizableEdges11;
            guna2TextBox2.DefaultText = "";
            guna2TextBox2.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox2.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox2.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox2.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox2.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox2.Font = new Font("Segoe UI", 10F);
            guna2TextBox2.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox2.Location = new Point(44, 188);
            guna2TextBox2.MaxLength = 150;
            guna2TextBox2.Multiline = true;
            guna2TextBox2.Name = "guna2TextBox2";
            guna2TextBox2.PasswordChar = '\0';
            guna2TextBox2.PlaceholderText = "Введите описание";
            guna2TextBox2.SelectedText = "";
            guna2TextBox2.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2TextBox2.Size = new Size(266, 72);
            guna2TextBox2.TabIndex = 22;
            // 
            // guna2TextBox1
            // 
            guna2TextBox1.Anchor = AnchorStyles.None;
            guna2TextBox1.BorderRadius = 12;
            guna2TextBox1.CustomizableEdges = customizableEdges13;
            guna2TextBox1.DefaultText = "";
            guna2TextBox1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Font = new Font("Segoe UI", 10F);
            guna2TextBox1.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Location = new Point(44, 120);
            guna2TextBox1.MaxLength = 50;
            guna2TextBox1.Name = "guna2TextBox1";
            guna2TextBox1.PasswordChar = '\0';
            guna2TextBox1.PlaceholderText = "Введите имя";
            guna2TextBox1.SelectedText = "";
            guna2TextBox1.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2TextBox1.Size = new Size(266, 41);
            guna2TextBox1.TabIndex = 21;
            // 
            // guna2BorderlessForm1
            // 
            guna2BorderlessForm1.BorderRadius = 10;
            guna2BorderlessForm1.ContainerControl = this;
            guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm1.DragStartTransparencyValue = 1D;
            guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // guna2DragControl1
            // 
            guna2DragControl1.DockIndicatorTransparencyValue = 0.6D;
            guna2DragControl1.DragStartTransparencyValue = 1D;
            guna2DragControl1.TargetControl = panel1;
            guna2DragControl1.UseTransparentDrag = true;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(35, 35, 35);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(guna2ControlBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(659, 43);
            panel1.TabIndex = 40;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.ForeColor = Color.White;
            label2.Location = new Point(10, 11);
            label2.Name = "label2";
            label2.Size = new Size(204, 20);
            label2.TabIndex = 3;
            label2.Text = "Изменение заявку на грант";
            // 
            // guna2ControlBox1
            // 
            guna2ControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2ControlBox1.Cursor = Cursors.Hand;
            guna2ControlBox1.CustomizableEdges = customizableEdges15;
            guna2ControlBox1.FillColor = Color.FromArgb(55, 55, 55);
            guna2ControlBox1.IconColor = Color.White;
            guna2ControlBox1.Location = new Point(621, 7);
            guna2ControlBox1.Name = "guna2ControlBox1";
            guna2ControlBox1.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2ControlBox1.Size = new Size(28, 28);
            guna2ControlBox1.TabIndex = 0;
            // 
            // FormEditRequest
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(659, 482);
            Controls.Add(panel1);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(guna2Button4);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(guna2DateTimePicker1);
            Controls.Add(guna2TextBox3);
            Controls.Add(label3);
            Controls.Add(guna2ComboBox3);
            Controls.Add(label1);
            Controls.Add(guna2ComboBox1);
            Controls.Add(guna2TextBox2);
            Controls.Add(guna2TextBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FormEditRequest";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormEditRequest";
            Load += FormEditRequest_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label10;
        private Label label9;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label4;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox3;
        private Label label3;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox3;
        private Label label1;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Panel panel1;
        private Label label2;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
    }
}