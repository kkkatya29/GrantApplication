﻿using GrantApplication.Repository;
using System.Data;

namespace GrantApplication.FormDialog;

public partial class FormEditOwner : Form
{
    private UserRepository UserRepository { get; set; } = new();
    private EmployeeRepository EmployeeRepository { get; set; } = new();
    private StudentRepository StudentRepository { get; set; } = new();
    public FormAdmin FormAdmin;
    private int UserId { get; set; }

    private DataTable EmployerFreeList { get; set; } = new();
    private DataTable StudentFreeList { get; set; } = new();

    /// <summary>
    /// Тип пользователя.  1 - client, 2 - employee
    /// </summary>
    private int TypePerson;

    public FormEditOwner(FormAdmin formAdmin, int userId)
    {
        InitializeComponent();
        FormAdmin = formAdmin;
        UserId = userId;
    }

    private void FormEditOwner_Load(object sender, EventArgs e)
    {
        TypePerson = 1;
        GetDataForList();
    }

    private void GetDataForList()
    {
        DataTable employeeData = EmployeeRepository.GetEmployeeAll();
        if (employeeData.Rows.Count > 0)
        {
            EmployerFreeList = employeeData.AsEnumerable()
            .Where(row => row.Field<string>("Логин для входа") == "Нет аккаунта")
            .CopyToDataTable();
        }

        DataTable dataTable = StudentRepository.GetStudentAll();
        if (dataTable.Rows.Count > 0)
        {
            StudentFreeList = dataTable.AsEnumerable()
                   .Where(row => row.Field<string>("Логин для входа") == "Нет аккаунта")
                   .CopyToDataTable();
        }
    }

    private void guna2RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        TypePerson = 2;
        SetDataCombobox();
    }

    private void SetDataCombobox()
    {
        if (guna2RadioButton1.Checked)
        {
            guna2ComboBox3.DataSource = EmployerFreeList;
            guna2ComboBox3.DisplayMember = "Сотрудник";
            guna2ComboBox3.ValueMember = "ID Сотрудника";
            guna2ComboBox3.SelectedIndex = 0;
        }
        else
        {
            guna2ComboBox3.DataSource = StudentFreeList;
            guna2ComboBox3.DisplayMember = "Студент";
            guna2ComboBox3.ValueMember = "ID Студента";
            guna2ComboBox3.SelectedIndex = 0;
        }
    }

    private void guna2RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
        SetDataCombobox();
    }

    private void guna2Button4_Click(object sender, EventArgs e)
    {
        if (guna2ComboBox3.SelectedIndex == -1)
        {
            MessageBox.Show("Получатель не выбран.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (UserRepository.OwnerAccountSet(UserId, (int)guna2ComboBox3.SelectedValue, TypePerson)) ;
        {
            MessageBox.Show("Аккаунт успешно выдан!", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            FormAdmin.LoadDataGrid();
            this.Close();
        }
    }
}
