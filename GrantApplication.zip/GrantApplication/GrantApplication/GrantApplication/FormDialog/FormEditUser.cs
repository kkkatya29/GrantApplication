﻿using GrantApplication.Model;
using GrantApplication.Repository;

namespace GrantApplication.FormDialog;

public partial class FormEditUser : Form
{
    private UserRepository UserRepository { get; set; } = new();
    FormAdmin FormAdmin { get; set; }
    private UserModel UserModel { get; set; }
    private int Option { get; set; }//1-add, 2-edit

    public FormEditUser(FormAdmin formAdmin, UserModel userModel, int option)
    {
        InitializeComponent();
        FormAdmin = formAdmin;
        UserModel = userModel;
        Option = option;
    }

    private void guna2Button4_Click(object sender, EventArgs e)
    {
        UserModel user = new()
        {
            UserId = UserModel.UserId,
            Role = guna2ComboBox3.SelectedItem.ToString(),
            Password = guna2TextBox2.Text,
            Login = guna2TextBox1.Text
        };

        if (Option == 2)
        {
            if (UserRepository.UpdateUser(user))
            {
                FormAdmin.LoadDataGrid();
                MessageBox.Show("Пользователь успешно изменен.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
        }
        else
        {
            if (UserRepository.CreateUser(user))
            {
                FormAdmin.LoadDataGrid();
                MessageBox.Show("Пользователь успешно добавлен.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
        }
    }

    private void FormEditUser_Load(object sender, EventArgs e)
    {
        if (Option == 2)
        {
            guna2TextBox1.Text = UserModel.Login;
            guna2ComboBox3.SelectedItem = UserModel.Role;
            label2.Text = "Изменение пользователя";
            guna2Button4.Text = "Применить";
        }
        else
        {
            label2.Text = "Добавление пользователя";
            guna2Button4.Text = "Добавить";
        }
    }
}
