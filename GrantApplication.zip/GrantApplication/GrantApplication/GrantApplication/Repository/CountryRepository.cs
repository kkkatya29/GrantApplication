﻿using GrantApplication.Infrastructure;
using Microsoft.Data.SqlClient;
using System.Data;

namespace GrantApplication.Repository;

public class CountryRepository
{
    private DataBase DataBase { get; set; } = new();

    /// <summary>
    /// Получает данные из таблицы стран.
    /// </summary>
    /// <returns>DataTable с данными из таблицы стран.</returns>
    public DataTable GetCountryAll()
    {
        DataTable dataTable = new();

        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("SELECT * FROM dbo.Страны с", connection);

            connection.Open();

            using SqlDataAdapter adapter = new(command);
            adapter.Fill(dataTable);
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при получении данных из таблицы стран: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        return dataTable;
    }
}
