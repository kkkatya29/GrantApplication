﻿using GrantApplication.Infrastructure;
using GrantApplication.Model;
using Microsoft.Data.SqlClient;
using System.Data;

namespace GrantApplication.Repository;

public class AttachDocumentRepository
{
    private DataBase DataBase { get; set; } = new();

    /// <summary>
    /// Создает новые вложенные файлы для заявок в базе данных.
    /// </summary>
    /// <param name="attachedFiles">Список моделей с данными</param>
    /// <returns>Возвращает список результатов, где каждый элемент содержит информацию о том, был ли файл успешно добавлен.</returns>
    public bool CreateAttachedFiles(List<AttachedFileModel> attachedFiles)
    {
        bool results = false;

        foreach (var attachedFile in attachedFiles)
        {
            if (!CreateAttachedFile(attachedFile))
            {
                return false;
            }
            results = true;
        }

        return results;
    }

    /// <summary>
    /// Создает новый вложенный файл для заявки в базе данных.
    /// </summary>
    /// <param name="attachedFile">Модель с данными</param>
    /// <returns>Возвращает true, если файл был успешно добавлен, иначе false.</returns>
    private bool CreateAttachedFile(AttachedFileModel attachedFile)
    {
        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("dbo.CreateAttachedFile", connection)
            {
                CommandType = CommandType.StoredProcedure
            };

            command.Parameters.AddWithValue("@File", attachedFile.File);
            command.Parameters.AddWithValue("@RequestId", attachedFile.RequestId);

            connection.Open();

            int rowsAffected = command.ExecuteNonQuery();

            return rowsAffected > 0;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при добавлении вложенного файла: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }
}
