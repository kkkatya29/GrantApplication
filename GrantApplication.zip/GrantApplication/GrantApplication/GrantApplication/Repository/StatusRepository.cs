﻿using GrantApplication.Infrastructure;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrantApplication.Repository;

public class StatusRepository
{
    private DataBase DataBase { get; set; } = new();

    /// <summary>
    /// Получает данные из таблицы статусов.
    /// </summary>
    /// <returns>DataTable с данными из таблицы статусов.</returns>
    public DataTable GetStatusAll()
    {
        DataTable dataTable = new();

        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("SELECT * FROM dbo.Статусы", connection);

            connection.Open();

            using SqlDataAdapter adapter = new(command);
            adapter.Fill(dataTable);
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при получении данных из таблицы статусов: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        return dataTable;
    }
}
