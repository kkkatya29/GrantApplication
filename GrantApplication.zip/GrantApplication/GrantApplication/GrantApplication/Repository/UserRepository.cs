﻿using GrantApplication.Infrastructure;
using GrantApplication.Model;
using GrantApplication.StaticModel;
using GrantApplication.Validator;
using Microsoft.Data.SqlClient;
using System.Data;

namespace GrantApplication.Repository;

public class UserRepository
{
    private DataBase DataBase { get; set; } = new();
    private UserValidator UserValidator { get; set; } = new();

    /// <summary>
    /// Создает нового пользователя.
    /// </summary>
    /// <param name="user">Модель данных пользователя для создания.</param>
    /// <returns>Возвращает true, если запись была добавлена, иначе false.</returns>
    public bool CreateUser(UserModel user)
    {
        try
        {
            if (!UserValidator.Validate(user))
            {
                return false;
            }

            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("dbo.CreateUser", connection)
            {
                CommandType = CommandType.StoredProcedure
            };

            command.Parameters.AddWithValue("@Login", user.Login);
            command.Parameters.AddWithValue("@Password", user.Password);
            command.Parameters.AddWithValue("@Role", user.Role);

            connection.Open();
            int rowsAffected = command.ExecuteNonQuery();

            return rowsAffected > 0;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при создании пользователя: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    /// <summary>
    /// Обновляет существующего пользователя.
    /// </summary>
    /// <param name="user">Модель данных пользователя для обновления.</param>
    /// <returns>Возвращает true, если запись была обновлена, иначе false.</returns>
    public bool UpdateUser(UserModel user)
    {
        try
        {
            if (!UserValidator.Validate(user))
            {
                return false;
            }

            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("dbo.UpdateUser", connection)
            {
                CommandType = CommandType.StoredProcedure
            };

            command.Parameters.AddWithValue("@Login", user.Login);
            command.Parameters.AddWithValue("@Password", user.Password);
            command.Parameters.AddWithValue("@Role", user.Role);
            command.Parameters.AddWithValue("@UserId", user.UserId);

            connection.Open();
            int rowsAffected = command.ExecuteNonQuery();

            return rowsAffected > 0;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при обновлении пользователя: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    /// <summary>
    /// Получает максимальный идентификатор пользователя из базы данных.
    /// </summary>
    /// <returns>Максимальный идентификатор пользователя, или -1 в случае ошибки.</returns>
    public int GetLastUserId()
    {
        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("SELECT dbo.LastUserGet()", connection);

            connection.Open();

            object result = command.ExecuteScalar();

            return result != null ? Convert.ToInt32(result) : -1;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при получении последнего идентификатора пользователя: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }
        catch (Exception ex)
        {
            // Общая обработка ошибок
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }
    }

    /// <summary>
    /// Получает данные из представления vw_User.
    /// </summary>
    /// <returns>DataTable с данными из представления vw_Request.</returns>
    public DataTable GetUserAll()
    {
        DataTable dataTable = new();

        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("SELECT * FROM vw_User", connection);

            connection.Open();

            using SqlDataAdapter adapter = new(command);
            adapter.Fill(dataTable);
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при получении данных из vw_User: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        return dataTable;
    }

    public bool DeleteUser(int userId)
    {
        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("dbo.DeleteUser", connection)
            {
                CommandType = CommandType.StoredProcedure
            };

            command.Parameters.AddWithValue("@UserId", userId);

            connection.Open();
            int rowsAffected = command.ExecuteNonQuery();

            return rowsAffected > 0;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при удалении пользователя: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    public bool OwnerAccountSet(int userId, int personId,int userType)
    {
        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("dbo.OwnerAccountSet", connection)
            {
                CommandType = CommandType.StoredProcedure
            };

            command.Parameters.AddWithValue("@UserId", userId);
            command.Parameters.AddWithValue("@OwnerId", personId);
            command.Parameters.AddWithValue("@UserType", userType);//1-client, 2-employee

            connection.Open();
            int rowsAffected = command.ExecuteNonQuery();

            return rowsAffected > 0;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при создании связи между пользователем и учетной записью: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    /// <summary>
    /// Выполняет вход пользователя в систему.
    /// </summary>
    /// <param name="user">Объект пользователя, содержащий логин и пароль.</param>
    /// <returns>Возвращает true, если вход успешен; иначе false.</returns>
    public bool LoginUser(UserModel user)
    {
        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            connection.Open();

            using SqlCommand command = new("dbo.LoginUser", connection);
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@Login", user.Login);
            command.Parameters.AddWithValue("@Password", user.Password);

            using SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                CurrentUser.UserId = reader.GetInt32(reader.GetOrdinal("ID Пользователя"));
                CurrentUser.PersonId = reader.IsDBNull(reader.GetOrdinal("ID Person")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("ID Person"));
                CurrentUser.Role = reader.GetString(reader.GetOrdinal("Роль"));

                return true; 
            }

            return false;
        }
        catch (Exception)
        {
            MessageBox.Show("Ошибка при входе в систему.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }
}

