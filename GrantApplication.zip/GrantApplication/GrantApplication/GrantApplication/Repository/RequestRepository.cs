﻿using GrantApplication.Infrastructure;
using GrantApplication.Model;
using GrantApplication.Validator;
using Microsoft.Data.SqlClient;
using System.Data;

namespace GrantApplication.Repository;

public class RequestRepository
{
    private DataBase DataBase { get; set; } = new();
    private RequestValidator RequestValidator { get; set; } = new();

    /// <summary>
    /// Создает новую заявку.
    /// </summary>
    /// <param name="request">Модель данных заявки для создания.</param>
    /// <returns>Возвращает true, если запись была добавлена, иначе false.</returns>
    public bool CreateRequest(RequestModel request)
    {
        try
        {
            if (!RequestValidator.Validate(request))
            {
                return false;
            }

            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("dbo.CreateRequest", connection)
            {
                CommandType = CommandType.StoredProcedure
            };

            command.Parameters.AddWithValue("@RequestName", request.RequestName);
            command.Parameters.AddWithValue("@Description", request.Description);
            command.Parameters.AddWithValue("@CountryId", request.CountryId);
            command.Parameters.AddWithValue("@ClientId", request.ClientId);
            command.Parameters.AddWithValue("@GrantTypeId", request.GrantTypeId);
            command.Parameters.AddWithValue("@Cost", request.Cost);
            command.Parameters.AddWithValue("@ApplicationDeadline", request.ApplicationDeadline);
            command.Parameters.AddWithValue("@StatusId", request.StatusId);

            connection.Open();
            int rowsAffected = command.ExecuteNonQuery();

            return rowsAffected > 0;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при создании заявки: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    /// <summary>
    /// Обновляет существующую заявку.
    /// </summary>
    /// <param name="request">Модель данных заявки для обновления.</param>
    /// <returns>Возвращает true, если запись была обновлена, иначе false.</returns>
    public bool UpdateRequest(RequestModel request)
    {
        try
        {
            if (!RequestValidator.Validate(request))
            {
                return false;
            }

            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("dbo.UpdateRequest", connection)
            {
                CommandType = CommandType.StoredProcedure
            };

            command.Parameters.AddWithValue("@RequestName", request.RequestName);
            command.Parameters.AddWithValue("@Description", request.Description);
            command.Parameters.AddWithValue("@CountryId", request.CountryId);
            command.Parameters.AddWithValue("@GrantTypeId", request.GrantTypeId);
            command.Parameters.AddWithValue("@Cost", request.Cost.Replace(',', '.'));
            command.Parameters.AddWithValue("@ApplicationDeadline", request.ApplicationDeadline);
            command.Parameters.AddWithValue("@RequestId", request.RequestId);

            connection.Open();
            int rowsAffected = command.ExecuteNonQuery();

            return rowsAffected > 0;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при обновлении заявки: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    /// <summary>
    /// Обновляет статус заявки в базе данных.
    /// </summary>
    /// <param name="statusId">Идентификатор статуса.</param>
    /// <param name="requestId">Идентификатор заявки.</param>
    /// <returns>Возвращает true, если статус был успешно обновлён, иначе false.</returns>
    public bool UpdateRequestStatus(RequestModel requestModel)
    {
        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("dbo.UpdateRequestStatus", connection)
            {
                CommandType = CommandType.StoredProcedure
            };

            command.Parameters.AddWithValue("@StatusId", requestModel.StatusId);
            command.Parameters.AddWithValue("@RequestId", requestModel.RequestId);

            connection.Open();

            int rowsAffected = command.ExecuteNonQuery();

            return rowsAffected > 0;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при обновлении статуса заявки: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    /// <summary>
    /// Получает данные из представления vw_Request.
    /// </summary>
    /// <returns>DataTable с данными из представления vw_Request.</returns>
    public DataTable GetRequestsAll()
    {
        DataTable dataTable = new();

        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("SELECT * FROM vw_Request", connection);

            connection.Open();

            using SqlDataAdapter adapter = new(command);
            adapter.Fill(dataTable);
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при получении данных из vw_Request: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        return dataTable;
    }

    /// <summary>
    /// Получает максимальный идентификатор запроса +1 из базы данных.
    /// </summary>
    /// <returns>Максимальный идентификатор пользователя, или -1 в случае ошибки.</returns>
    public int GetRequestNewId()
    {
        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("SELECT dbo.LastRequestGet()", connection);

            connection.Open();

            object result = command.ExecuteScalar();

            return result != null ? Convert.ToInt32(result) + 1 : -1;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при получении последнего идентификатора запроса: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }
    }
}