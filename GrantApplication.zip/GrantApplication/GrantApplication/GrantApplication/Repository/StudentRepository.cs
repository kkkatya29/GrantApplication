﻿using GrantApplication.Infrastructure;
using GrantApplication.Model;
using Microsoft.Data.SqlClient;
using System.Data;

namespace GrantApplication.Repository;

public class StudentRepository
{
    private DataBase DataBase { get; set; } = new();

    /// <summary>
    /// Создает нового студента.
    /// </summary>
    /// <param name="student">Модель данных студента для создания.</param>
    /// <returns>Возвращает true, если запись была добавлена, иначе false.</returns>
    public bool CreateStudent(StudentModel student)
    {
        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("dbo.CreateStudent", connection)
            {
                CommandType = CommandType.StoredProcedure
            };

            command.Parameters.AddWithValue("@FirstName", student.FirstName);
            command.Parameters.AddWithValue("@LastName", student.LastName);
            command.Parameters.AddWithValue("@MiddleName", student.MiddleName);
            command.Parameters.AddWithValue("@EducationId", student.EducationId);

            connection.Open();
            int rowsAffected = command.ExecuteNonQuery();

            return rowsAffected > 0;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при создании студента: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    /// <summary>
    /// Получает максимальный идентификатор студента из базы данных.
    /// </summary>
    /// <returns>Максимальный идентификатор студента, или -1 в случае ошибки.</returns>
    public int GetLastStudentId()
    {
        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("SELECT dbo.LastStudentGet()", connection);

            connection.Open();

            object result = command.ExecuteScalar();

            return result != null ? Convert.ToInt32(result) : -1;
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при получении последнего идентификатора студента: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }
    }

    public DataTable GetStudentAll()
    {
        DataTable dataTable = new();

        try
        {
            using SqlConnection connection = new(DataBase.connectionString);
            using SqlCommand command = new("SELECT * FROM vw_Student", connection);

            connection.Open();

            using SqlDataAdapter adapter = new(command);
            adapter.Fill(dataTable);
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка при получении данных из vw_Student: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Неожиданная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        return dataTable;
    }
}
