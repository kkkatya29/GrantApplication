﻿namespace GrantApplication.StaticModel;

public class CurrentUser
{
    /// <summary>
    /// Роль учетной записи под которой вошли.
    /// </summary>
    public static string? Role { get; set; } = "Админ";

    /// <summary>
    /// ID Пользователя (id учетной записи под которой вошли).
    /// </summary>
    public static int UserId { get; set; } = 1;

    /// <summary>
    /// ID Человека, который вошел (студент, сотрудник и тд).
    /// </summary>
    public static int? PersonId { get; set; } = 1;
}
