﻿namespace GrantApplication.Infrastructure;

public class DataBase
{
    public string connectionString = $@"Data Source=KATYA_LD\MSSQLSERVER3;Initial Catalog=Grant;Integrated Security=True;TrustServerCertificate=True";
}
