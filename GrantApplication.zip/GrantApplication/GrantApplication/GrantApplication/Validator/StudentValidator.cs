﻿using GrantApplication.Model;

namespace GrantApplication.Validator;

public class StudentValidator
{
    public bool Validate(StudentModel student)
    {
        if (string.IsNullOrWhiteSpace(student.FirstName) || student.FirstName.Length > 50)
        {
            MessageBox.Show("Имя не может быть пустым и должно содержать не более 50 символов.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (string.IsNullOrWhiteSpace(student.LastName) || student.LastName.Length > 50)
        {
            MessageBox.Show("Фамилия не может быть пустой и должна содержать не более 50 символов.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (string.IsNullOrWhiteSpace(student.MiddleName) || student.MiddleName.Length > 50)
        {
            MessageBox.Show("Отчество не может быть пустым и должно содержать не более 50 символов.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        return true;
    }
}
