﻿using GrantApplication.Model;
using System.Text.RegularExpressions;

namespace GrantApplication.Validator;

public class UserValidator
{
    public bool Validate(UserModel user)
    {
        if (string.IsNullOrWhiteSpace(user.Login) || user.Login.Length < 3 || user.Login.Length > 50)
        {
            MessageBox.Show("Логин не может быть пустым и должен содержать от 3 до 50 символов.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (Regex.IsMatch(user.Login, @"[^a-zA-Z0-9]"))
        {
            MessageBox.Show("Логин не должен содержать специальных символов.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (string.IsNullOrWhiteSpace(user.Password) || user.Password.Length < 6 || user.Password.Length > 50)
        {
            MessageBox.Show("Пароль не может быть пустым и должен содержать от 6 до 50 символов.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (!Regex.IsMatch(user.Password, @"[A-Z]"))
        {
            MessageBox.Show("Пароль должен содержать хотя бы одну заглавную латинскую букву.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (!Regex.IsMatch(user.Password, @"[!@#$%^&*()_+\-=\[\]{};':""\\|,.<>\/?]"))
        {
            MessageBox.Show("Пароль должен содержать хотя бы один специальный символ.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        return true;
    }
}
