﻿using GrantApplication.Model;

namespace GrantApplication.Validator;

public class RequestValidator
{
    public bool Validate(RequestModel request)
    {
        if (string.IsNullOrWhiteSpace(request.RequestName) || request.RequestName.Length > 50)
        {
            MessageBox.Show("Наименование заявки не может быть пустым и должно содержать не более 50 символов.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (string.IsNullOrWhiteSpace(request.Description) || request.Description.Length > 150)
        {
            MessageBox.Show("Описание заявки не может быть пустым и должно содержать не более 150 символов.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (!decimal.TryParse(request.Cost, out decimal cost) || cost < 0)
        {
            MessageBox.Show("Сумма должна быть корректным числом и не может быть отрицательной.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        return true;
    }
}
