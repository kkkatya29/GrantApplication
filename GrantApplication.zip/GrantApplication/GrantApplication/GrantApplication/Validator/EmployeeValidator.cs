﻿using GrantApplication.Model;

namespace GrantApplication.Validator;

public class EmployeeValidator
{
    public bool Validate(EmployeeModel employee)
    {
        if (string.IsNullOrWhiteSpace(employee.FirstName) || employee.FirstName.Length > 50)
        {
            MessageBox.Show("Имя сотрудника не может быть пустым и должно содержать не более 50 символов.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (string.IsNullOrWhiteSpace(employee.LastName) || employee.LastName.Length > 50)
        {
            MessageBox.Show("Фамилия сотрудника не может быть пустой и должна содержать не более 50 символов.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        if (string.IsNullOrWhiteSpace(employee.MiddleName) || employee.MiddleName.Length > 50)
        {
            MessageBox.Show("Отчество сотрудника не может быть пустым и должно содержать не более 50 символов.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        return true;
    }
}
