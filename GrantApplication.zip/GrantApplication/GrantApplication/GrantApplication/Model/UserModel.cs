﻿namespace GrantApplication.Model;

public class UserModel
{
    public string Login { get; set; }
    public string Password { get; set; }
    public string Role { get; set; }
    public int UserId { get; set; }
}
