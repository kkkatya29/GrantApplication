﻿namespace GrantApplication.Model;

public class RequestModel
{
    public int RequestId { get; set; }
    public string? RequestName { get; set; } 
    public string? Description { get; set; }
    public int CountryId { get; set; }
    public int? ClientId { get; set; }
    public int GrantTypeId { get; set; }
    public string? Cost { get; set; }
    public DateTime? ApplicationDeadline { get; set; }
    public int StatusId { get; set; }
}

