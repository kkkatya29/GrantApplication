﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrantApplication.Model;

public class AttachedFileModel
{
    /// <summary>
    /// Содержимое файла в виде массива байтов.
    /// </summary>
    public byte[] File { get; set; }

    /// <summary>
    /// Идентификатор заявки, связанной с файлом.
    /// </summary>
    public int RequestId { get; set; }
}
