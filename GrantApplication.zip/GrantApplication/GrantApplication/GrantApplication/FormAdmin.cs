﻿using GrantApplication.FormDialog;
using GrantApplication.Model;
using GrantApplication.Repository;
using Microsoft.VisualBasic.ApplicationServices;

namespace GrantApplication;

public partial class FormAdmin : Form
{
    private UserRepository UserRepository { get; set; } = new();
    private BindingSource BindingSource { get; set; } = new();

    public FormAdmin()
    {
        InitializeComponent();
    }

    private void FormAdmin_Load(object sender, EventArgs e)
    {
        LoadDataGrid();
        SetVisibleColumn();
    }

    public void LoadDataGrid()
    {
        BindingSource.DataSource = UserRepository.GetUserAll();
        guna2DataGridView1.DataSource = BindingSource;
    }

    private void SetVisibleColumn()
    {
        using DataGridViewColumn Column1 = guna2DataGridView1.Columns["ID Пользователя"];
        Column1.Visible = false;
    }

    private void guna2TextBox1_TextChanged(object sender, EventArgs e)
    {
        FilterData(guna2TextBox1.Text);
    }

    private void FilterData(string searchText)
    {
        if (string.IsNullOrWhiteSpace(searchText))
        {
            BindingSource.RemoveFilter();
        }
        else
        {
            BindingSource.Filter = $"CONVERT([Роль], 'System.String') LIKE '%{searchText}%' OR " +
                                   $"CONVERT([Логин], 'System.String') LIKE '%{searchText}%' OR " +
                                   $"CONVERT([Владелец аккаунта], 'System.String') LIKE '%{searchText}%'";
        }
    }

    private void guna2Button1_Click(object sender, EventArgs e)
    {
        FormEditUser form = new(this, new(), 1);
        form.ShowDialog();
    }

    private void guna2Button3_Click(object sender, EventArgs e)
    {
        UserModel user = new()
        {
            UserId = (int)guna2DataGridView1.SelectedRows[0].Cells["ID Пользователя"].Value,
            Role = guna2DataGridView1.SelectedRows[0].Cells["Роль"].Value.ToString(),
            Login = guna2DataGridView1.SelectedRows[0].Cells["Логин"].Value.ToString(),
            Password = string.Empty
        };

        FormEditUser form = new(this, user, 2);
        form.ShowDialog();
    }

    private void guna2Button2_Click(object sender, EventArgs e)
    {
        DialogResult result = MessageBox.Show("Вы уверены, что хотите удалить пользователя?", "Подтверждение",
        MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (result != DialogResult.Yes)
        {
            MessageBox.Show("Действие отменено.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        if (UserRepository.DeleteUser((int)guna2DataGridView1.SelectedRows[0].Cells["ID Пользователя"].Value))
        {
            LoadDataGrid();
            MessageBox.Show("Пользователь успешно удален.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
    }

    private void guna2Button4_Click(object sender, EventArgs e)
    {
        if (guna2DataGridView1.SelectedRows[0].Cells["Владелец аккаунта"].Value.ToString() !="Нет владельца")
        {
            MessageBox.Show("Этот аккаунт уже занят.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        int selectedUserId = (int)guna2DataGridView1.SelectedRows[0].Cells["ID Пользователя"].Value;

        FormEditOwner form = new(this, selectedUserId);
        form.ShowDialog();
    }
}
