﻿using GrantApplication.Model;
using GrantApplication.Repository;
using GrantApplication.StaticModel;
using Guna.UI2.WinForms;

namespace GrantApplication;

public partial class FormCreateRequest : Form
{
    private RequestRepository RequestRepository { get; set; } = new();
    private AttachDocumentRepository AttachDocumentRepository { get; set; } = new();
    private List<AttachedFileModel> selectedFiles { get; set; } = new();
    private GrantRepository GrantRepository { get; set; } = new();
    private CountryRepository CountryRepository { get; set; } = new();

    private OpenFileDialog openFileDialog;

    public FormCreateRequest()
    {
        InitializeComponent();

        openFileDialog = new OpenFileDialog
        {
            Filter = "PDF Files (*.pdf)|*.pdf",
            Title = "Select a PDF File"
        };
    }

    private void FormCreateRequest_Load(object sender, EventArgs e)
    {
        FillCombobox();
    }

    private void guna2Button3_Click(object sender, EventArgs e)
    {
        if (openFileDialog.ShowDialog() == DialogResult.OK)
        {
            string filePath = openFileDialog.FileName;

            int requestId = RequestRepository.GetRequestNewId();
            byte[] fileBytes = File.ReadAllBytes(filePath);

            selectedFiles.Add(new AttachedFileModel { File = fileBytes, RequestId = requestId });
            guna2Button3.Enabled = false;
            MessageBox.Show($"Файл 'Сертификат' загружен.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    private void guna2Button4_Click(object sender, EventArgs e)
    {
        RequestModel request = new()
        {
            ApplicationDeadline = DateTime.Now,
            RequestName = guna2TextBox1.Text,
            Description = guna2TextBox2.Text,
            GrantTypeId = (int)guna2ComboBox3.SelectedValue,
            CountryId = (int)guna2ComboBox1.SelectedValue,
            Cost = guna2TextBox3.Text,
            ClientId = CurrentUser.PersonId,
            StatusId = 1
        };

        if (selectedFiles.Count != 3)
        {
            MessageBox.Show("Необходимо выбрать все три файла\r\nВ ином случае загрузите пустой файл.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (!RequestRepository.CreateRequest(request))
        {
            return;
        }

        if (!AttachDocumentRepository.CreateAttachedFiles(selectedFiles))
        {
            return;
        }
        panel1.Visible = false;
        guna2Button4.Enabled = false;
        guna2Button4.Text = "Заявка отправлена";
        MessageBox.Show("Заявка успешно отправлена!", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void guna2Button1_Click(object sender, EventArgs e)
    {
        if (openFileDialog.ShowDialog() == DialogResult.OK)
        {
            string filePath = openFileDialog.FileName;

            int requestId = RequestRepository.GetRequestNewId();
            byte[] fileBytes = File.ReadAllBytes(filePath);

            selectedFiles.Add(new AttachedFileModel { File = fileBytes, RequestId = requestId });
            guna2Button1.Enabled = false;
            MessageBox.Show($"Файл 'Резюме' загружен.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    private void guna2Button2_Click(object sender, EventArgs e)
    {
        if (openFileDialog.ShowDialog() == DialogResult.OK)
        {
            string filePath = openFileDialog.FileName;

            int requestId = RequestRepository.GetRequestNewId();
            byte[] fileBytes = File.ReadAllBytes(filePath);

            selectedFiles.Add(new AttachedFileModel { File = fileBytes, RequestId = requestId });
            guna2Button2.Enabled = false;
            MessageBox.Show($"Файл 'Письмо' загружен.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    private void FillCombobox()
    {
        guna2ComboBox1.DataSource = CountryRepository.GetCountryAll();
        guna2ComboBox1.DisplayMember = "Наименование";
        guna2ComboBox1.ValueMember = "ID Страны";
        guna2ComboBox1.SelectedIndex = 0;

        guna2ComboBox3.DataSource = GrantRepository.GetGrantAll();
        guna2ComboBox3.DisplayMember = "Наименование";
        guna2ComboBox3.ValueMember = "ID Вида гранта";
        guna2ComboBox3.SelectedIndex = 0;
    }
}
