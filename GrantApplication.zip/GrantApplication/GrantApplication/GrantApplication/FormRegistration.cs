﻿using GrantApplication.Model;
using GrantApplication.Repository;
using GrantApplication.Validator;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GrantApplication;

public partial class FormRegistration : Form
{
    private UserValidator UserValidator { get; set; } = new();
    public FormRegistration()
    {
        InitializeComponent();
    }

    private void panel1_Paint(object sender, PaintEventArgs e)
    {

    }

    private void label2_Click(object sender, EventArgs e)
    {
        FormLogin form = new();
        form.Show();
        this.Hide();
    }

    private void FormRegistration_Load(object sender, EventArgs e)
    {
        guna2CheckBox1.Checked = true;
    }

    private void guna2Button4_Click(object sender, EventArgs e)
    {
        if (guna2TextBox2.Text != guna2TextBox3.Text)
        {
            MessageBox.Show("Пароли не совпадают.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        UserModel user = new()
        {
            Password = guna2TextBox2.Text,
            Role = "Клиент",
            Login = guna2TextBox1.Text
        };


        if (!UserValidator.Validate(user))
        {
            return;
        }

        FormFillPersonalData form = new(user);
        form.Show();
        this.Hide();
    }

    private void guna2CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        guna2TextBox2.UseSystemPasswordChar = guna2TextBox3.UseSystemPasswordChar = guna2CheckBox1.Checked;
    }
}
