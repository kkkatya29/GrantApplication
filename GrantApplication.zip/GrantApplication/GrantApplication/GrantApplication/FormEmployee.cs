﻿using Azure.Core;
using GrantApplication.FormDialog;
using GrantApplication.Model;
using GrantApplication.Repository;

namespace GrantApplication;

public partial class FormEmployee : Form
{
    private EmployeeRepository EmployeeRepository { get; set; } = new();
    private BindingSource BindingSource { get; set; } = new();

    public FormEmployee()
    {
        InitializeComponent();
    }

    private void FormEmployee_Load(object sender, EventArgs e)
    {
        LoadDataGrid();
        SetVisibleColumn();
    }

    public void LoadDataGrid()
    {
        BindingSource.DataSource = EmployeeRepository.GetEmployeeAll();
        guna2DataGridView1.DataSource = BindingSource;
    }

    private void SetVisibleColumn()
    {
        using DataGridViewColumn EmployeeId = guna2DataGridView1.Columns["ID Сотрудника"];
        EmployeeId.Visible = false;
        using DataGridViewColumn Column1 = guna2DataGridView1.Columns["ID Пользователя"];
        Column1.Visible = false;
    }

    private void guna2TextBox1_TextChanged(object sender, EventArgs e)
    {
        FilterData(guna2TextBox1.Text);
    }

    private void FilterData(string searchText)
    {
        if (string.IsNullOrWhiteSpace(searchText))
        {
            BindingSource.RemoveFilter();
        }
        else
        {
            BindingSource.Filter = $"CONVERT([Сотрудник], 'System.String') LIKE '%{searchText}%' OR " +
                                   $"CONVERT([Логин для входа], 'System.String') LIKE '%{searchText}%' OR " +
                                   $"CONVERT([Дата трудоустройства], 'System.String') LIKE '%{searchText}%'";
        }
    }

    private void guna2Button1_Click(object sender, EventArgs e)
    {
        FormEditEmployee form = new(this, new(), 1);
        form.ShowDialog();
    }

    private void guna2Button3_Click(object sender, EventArgs e)
    {
        if (guna2DataGridView1.SelectedRows.Count < 0)
        {
            MessageBox.Show("Для изменения выберите сотрудника из списка.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        EmployeeModel employee = new()
        {
            EmployeeId = (int)guna2DataGridView1.SelectedRows[0].Cells["ID Сотрудника"].Value,
            FirstName = guna2DataGridView1.SelectedRows[0].Cells["Имя"].Value.ToString(),
            LastName = guna2DataGridView1.SelectedRows[0].Cells["Фамилия"].Value.ToString(),
            MiddleName = guna2DataGridView1.SelectedRows[0].Cells["Отчество"].Value.ToString()
        };
        FormEditEmployee form = new(this, employee, 2);
        form.ShowDialog();
    }
}