﻿using GrantApplication.FormDialog;
using GrantApplication.Model;
using GrantApplication.Repository;
using GrantApplication.StaticModel;
using System.Data;

namespace GrantApplication;

public partial class FormManipulationRequest : Form
{
    private RequestRepository RequestRepository { get; set; } = new();
    private BindingSource BindingSource { get; set; } = new();

    public FormManipulationRequest()
    {
        InitializeComponent();
    }

    private void FormManipulationRequest_Load(object sender, EventArgs e)
    {
        LoadDataGrid();
        SetVisibleColumn();
        SetAccess(CurrentUser.Role);
    }

    /// <summary>
    /// Если вошел сотрудник, то отображаем ему все записи. Клиенту отображаем только закрепленные за ним заявки
    /// </summary>
    public void LoadDataGrid()
    {
        DataTable allRequests = RequestRepository.GetRequestsAll();

        if (CurrentUser.Role.ToLower() == "клиент")
        {
            var filteredRequests = allRequests.AsEnumerable()
            .Where(row => row.Field<int>("ID Студента") == CurrentUser.PersonId);

            if (filteredRequests.Any())
            {
                BindingSource.DataSource = filteredRequests.CopyToDataTable();
                guna2DataGridView1.DataSource = BindingSource;
            }
        }
        else
        {
            BindingSource.DataSource = allRequests;
            guna2DataGridView1.DataSource = BindingSource;
        }
    }

    private void FilterData(string searchText)
    {
        if (string.IsNullOrWhiteSpace(searchText))
        {
            BindingSource.RemoveFilter();
        }
        else
        {
            BindingSource.Filter = $"CONVERT([Наименование заявки], 'System.String') LIKE '%{searchText}%' OR " +
                                   $"CONVERT([Описание], 'System.String') LIKE '%{searchText}%' OR " +
                                   $"CONVERT([Страна], 'System.String') LIKE '%{searchText}%' OR " +
                                   $"CONVERT([Вид гранта], 'System.String') LIKE '%{searchText}%' OR " +
                                   $"CONVERT([Сумма], 'System.String') LIKE '%{searchText}%' OR " +
                                   $"CONVERT([Статус], 'System.String') LIKE '%{searchText}%' OR " +
                                   $"CONVERT([Срок подачи], 'System.String') LIKE '%{searchText}%' OR " +
                                   $"CONVERT([Учебное заведение], 'System.String') LIKE '%{searchText}%'";
        }
    }

    private void SetVisibleColumn()
    {
        if (guna2DataGridView1.RowCount < 1)
        {
            return;
        }

        using DataGridViewColumn Column1 = guna2DataGridView1.Columns["ID Заявки"];
        Column1.Visible = false;
        using DataGridViewColumn Column2 = guna2DataGridView1.Columns["ID Статуса"];
        Column2.Visible = false;
        using DataGridViewColumn Column3 = guna2DataGridView1.Columns["ID Студента"];
        Column3.Visible = false;
        using DataGridViewColumn Column4 = guna2DataGridView1.Columns["ID Вида гранта"];
        Column4.Visible = false;
        using DataGridViewColumn Column5 = guna2DataGridView1.Columns["ID Страны"];
        Column5.Visible = false;
        using DataGridViewColumn Column6 = guna2DataGridView1.Columns["ID Учебного заведения"];
        Column6.Visible = false;
    }

    private void SetAccess(string? role)
    {
        switch (role?.ToLower())
        {
            case "клиент":
                guna2Button1.Dispose();
                break;
            case "админ":
                break;
            case "менеджер":
                break;
            default:
                MessageBox.Show("Роль некорректная.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                break;
        }
    }

    private void guna2TextBox1_TextChanged(object sender, EventArgs e)
    {
        FilterData(guna2TextBox1.Text);
    }

    private void guna2Button1_Click(object sender, EventArgs e)
    {
        if (guna2DataGridView1.SelectedRows.Count < 0)
        {
            MessageBox.Show("Для изменения статуса выберите заявку из списка.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        RequestModel request = new()
        {
            RequestId = (int)guna2DataGridView1.SelectedRows[0].Cells["ID Заявки"].Value,
            StatusId = (int)guna2DataGridView1.SelectedRows[0].Cells["ID Статуса"].Value
        };

        FormEditRequestStatus form = new(this, request);
        form.ShowDialog();
    }

    private void guna2Button3_Click(object sender, EventArgs e)
    {
        if (guna2DataGridView1.SelectedRows.Count < 0)
        {
            MessageBox.Show("Для изменения выберите заявку из списка.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        RequestModel request = new()
        {
            RequestId = (int)guna2DataGridView1.SelectedRows[0].Cells["ID Заявки"].Value,
            RequestName = guna2DataGridView1.SelectedRows[0].Cells["Наименование заявки"].Value.ToString(),
            Description = guna2DataGridView1.SelectedRows[0].Cells["Описание"].Value.ToString(),
            GrantTypeId = (int)guna2DataGridView1.SelectedRows[0].Cells["ID Вида гранта"].Value,
            CountryId = (int)guna2DataGridView1.SelectedRows[0].Cells["ID Страны"].Value,
            Cost = guna2DataGridView1.SelectedRows[0].Cells["Сумма"].Value.ToString(),
            ApplicationDeadline = (DateTime)guna2DataGridView1.SelectedRows[0].Cells["Срок подачи"].Value
        };

        FormEditRequest form = new(this, request);
        form.ShowDialog();
    }
}
